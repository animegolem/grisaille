import { test, expect, mock } from 'bun:test';
import * as gpui from '@gpuix/react';
import { createTestRoot } from '@gpuix/react/testing';
import { mkdtempSync, readFileSync, writeFileSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import { contrast } from '/Users/golem/git/grisaille/.workspaces/code-lead/primary/src/theme';

const repo = '/Users/golem/git/grisaille/.workspaces/code-lead/primary';
const directory = mkdtempSync(join(import.meta.dir, 'app-binding-probe-'));
const fixture = JSON.parse(readFileSync(join(repo, 'tests/fixtures/palette/ok.json'), 'utf8'));
fixture.track.file = 'sample/loveless/0';
function publish(value: unknown) {
  writeFileSync(join(directory, 'palette.tmp'), JSON.stringify(value), {mode:0o600});
  renameSync(join(directory, 'palette.tmp'), join(directory, 'palette.json'));
}
publish(fixture);
process.argv.push('--demo','--theme-probe');
process.env.MUSIC_UI_THEME_PROBE_DIR = directory;
process.env.GPUIX_BACKGROUND = '1';
let captured: { element: unknown; options: any };
// Only swap the process-level rendering entry point. Actual App source,
// providers, input helper, palette source and demo model are unmodified.
mock.module('@gpuix/react', () => ({ ...gpui, render: (element: unknown, options: unknown) => { captured = {element, options}; } }));

test('actual native App preserves the drag-source pair at a different destination and updates the seek backdrop', async () => {
  await import('/Users/golem/git/grisaille/.workspaces/code-lead/primary/src/app');
  expect(captured!).toBeDefined();
  const view = createTestRoot({width:1120,height:820,onKeyDown:captured!.options.onKeyDown});
  const r=view.renderer;
  const wait = async (check:()=>boolean) => {
    const end=Date.now()+5000;
    for (;;) { r.flush(); r.dispatchNativeEvents(); if(check()) return; if(Date.now()>end) throw Error('review App condition timeout'); await Bun.sleep(10); }
  };
  const descend=(id:number):any[]=>{const e=r.getElement(id)!; return [e,...e.children.flatMap(descend)];};
  const preview=()=>r.findByType('div').find(e=>e.style.pointerEvents==='none' && e.style.position==='absolute' && e.style.height===68);
  try {
    view.render(captured!.element as any);
    await wait(()=>r.findByTestId('music-root')?.style.background===fixture.roles.background.hex && !!r.findByTestId('queue-1'));
    const first=r.findByTestId('queue-1')!;
    expect(first.style.background).toBe(fixture.roles.selection.hex);
    r.simulateKeystrokes('m j');
    await wait(()=>!!preview());
    let p=preview()!;
    expect(p.style.background).toBe(fixture.roles.selection.hex);
    let labels=descend(p.id).filter(e=>e.type==='text' && ['Only Shallow','▸','→ 2'].includes(e.text));
    expect(labels.map(e=>e.text).sort()).toEqual(['Only Shallow','▸','→ 2'].sort());
    const effectiveColor=(e:any):unknown=>e.style.color ?? (e.parentId ? effectiveColor(r.getElement(e.parentId)) : undefined);
    for(const e of labels) expect(effectiveColor(e)).toBe(fixture.roles.highlight_text.hex);
    expect(r.findByTestId('queue-2')!.style.background).toBe(fixture.roles.background.hex);
    expect(r.findByTestId('queue-1')!.style.opacity).toBe(0.45);
    // Control: a selected, nonplaying source must not acquire the playing cue.
    r.simulateKeystrokes('escape j m k');
    await wait(()=>!!preview() && descend(preview()!.id).some(e=>e.text==='Loomer'));
    p=preview()!;
    expect(p.style.background).toBe(fixture.roles.selection.hex);
    expect(descend(p.id).some(e=>e.text==='▸')).toBe(false);
    expect(effectiveColor(descend(p.id).find(e=>e.text==='Loomer')!)).toBe(fixture.roles.highlight_text.hex);
    r.simulateKeystrokes('escape');
    const ramp=JSON.parse(readFileSync(join(repo,'tests/fixtures/palette/host-ramp.json'),'utf8'));
    const mono=ramp.cases.find((x:any)=>x.name==='gray-00').artifact;
    publish(mono);
    await wait(()=>r.findByTestId('music-root')?.style.background==='#000000');
    const seek=r.findByTestId('seek')!;
    const track=r.getElement(seek.children[0])!, fill=r.getElement(track.children[0])!;
    expect(track.style.background).toBe('#000000');
    expect(contrast(fill.style.background as string,track.style.background as string)).toBeGreaterThanOrEqual(3);
    expect(contrast(track.style.borderColor as string,track.style.background as string)).toBeGreaterThanOrEqual(3);
    expect(track.style.borderWidth).toBe(1);
  } finally { view.unmount(); }
},15000);

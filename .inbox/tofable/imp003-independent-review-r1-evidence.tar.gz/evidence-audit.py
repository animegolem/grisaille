import hashlib
import importlib.util
import json
from pathlib import Path
from PIL import Image

repo = Path('/Users/golem/git/grisaille/.workspaces/code-lead/primary')
evidence = Path('/Users/golem/git/grisaille/.inbox/tofable/imp003-theme-candidate-r1-evidence')
out = Path(__file__).parent
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
results = {}
manifest = read(evidence / 'manifest.json')
results['manifest'] = [dict(file=x['file'], copy=digest(evidence/x['file'])==x['sha256'], original=digest(x['source'])==x['sha256']) for x in manifest]
assert all(x['copy'] and x['original'] for x in results['manifest'])
native = read(evidence/'native-report.json')
results['native'] = dict(passed=native['passed'], error=native['error'], cases=[])
assert native['passed'] is False
assert digest(repo/'dist/music-ui') == native['binary_sha256']
for case in native['cases']:
    path = Path(native['output']) / case['screenshot']
    assert digest(path) == case['sha256']
    im = Image.open(path)
    expected = tuple(bytes.fromhex(case['expectedBackground'][1:]))
    bounds = case['rootBounds']
    x, y = round(5*im.width/bounds['width']), round(100*im.height/bounds['height'])
    rgb = im.convert('RGB')
    exact = all(rgb.getpixel((x+dx,y+dy)) == expected for dx in range(4) for dy in range(4))
    assert exact
    results['native']['cases'].append(dict(name=case['name'], hash=True, exact=exact, size=im.size, mode=im.mode, profileKeys=list(im.info)))
pty = read(evidence/'pty-report.json')
spec = importlib.util.spec_from_file_location('capture', repo/'scripts/capture-theme-terminal.py')
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
results['pty'] = dict(passed=pty['passed'], cases=[])
assert digest(Path(pty['output'])/'session.ansi') == pty['session_ansi_sha256']
for case in pty['cases']:
    path = Path(pty['output'])/case['raw_ansi']
    data = path.read_bytes()
    assert digest(path) == case['raw_sha256']
    colors = capture.background_colors(data)
    assert tuple(case['expected_rgb']) in colors
    results['pty']['cases'].append(dict(name=case['name'], hash=True, expected_count=colors.count(tuple(case['expected_rgb']))))
def inputs(x):
    if isinstance(x,dict):
        here = [dict(id=x.get('id'), testId=x.get('testId'), customProps=x.get('customProps'))] if x.get('testId','').startswith('prompt-input') else []
        return here + [y for v in x.values() for y in inputs(v)]
    if isinstance(x,list): return [y for v in x for y in inputs(v)]
    return []
for name, directory in [('ime','/tmp/grisaille-imp003-ime-r4-20261009'),('blur','/tmp/grisaille-imp003-blur-r2-20261009')]:
    a = read(evidence/f'{name}-interactive.json')
    result=[]
    for record in a['observations']:
        assert digest(Path(directory)/record['screenshot']) == record['sha256']
        result.append(dict(name=record['name'], screenshot_hash=True, inputs=inputs(record['tree'])))
    results[name] = result
    if name=='ime':
        c=a['compositionPublication']
        assert digest(Path(directory)/c['screenshot'])==c['sha256']
        results['ime_bounds'] = dict(arm_to_handler_ms=c['event']['observedAtMs']-c['armedAtMs'], arm_to_capture_ms=c['capturedAtMs']-c['armedAtMs'])
for sample in read(evidence/'field-pixel-samples.json'):
    assert digest(sample['file'])==sample['sha256']
    im=Image.open(sample['file']).convert('RGB').crop(sample['crop'])
    expected=tuple(sample.get('expectedForeground',sample.get('expectedCaret')))
    count=sum(1 for pixel in im.getdata() if pixel==expected)
    assert count==sample.get('exactForegroundPixels',sample.get('matchingPixels'))
results['field_pixel_samples']='3/3 hashes and exact counts reproduced'
(out/'evidence-audit.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(dict(manifest=len(manifest),native_patches=len(native['cases']),native_passed=native['passed'],pty_cases=len(pty['cases']),input_records=results['ime']+results['blur'],bounds=results['ime_bounds'],fields=results['field_pixel_samples']),indent=2))

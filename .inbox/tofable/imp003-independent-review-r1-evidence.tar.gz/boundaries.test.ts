import { test, expect } from 'bun:test';
import { spawnSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync, statSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { NavigationStateStore, parseNavigationState } from '/Users/golem/git/grisaille/.workspaces/code-lead/primary/src/navigation-state';
import { decodePaletteArtifact } from '/Users/golem/git/grisaille/.workspaces/code-lead/primary/src/palette-contract';
import { mapPaletteToTheme, contrast, pairForState } from '/Users/golem/git/grisaille/.workspaces/code-lead/primary/src/theme';
import { defaultOrder } from '/Users/golem/git/grisaille/.workspaces/code-lead/primary/src/library-order';

const repo='/Users/golem/git/grisaille/.workspaces/code-lead/primary';
const out=join(import.meta.dir,'boundaries');
mkdirSync(out,{recursive:true,mode:0o700});
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
test('compiled native entry refuses invalid probe opt-ins before creating state',()=>{
  const env={...process.env,MUSIC_UI_THEME_PROBE_DIR:undefined,MUSIC_UI_STATE_DIR:join(out,'never-state'),GPUIX_BACKGROUND:'1'};
  const cases=[
    {args:['--demo','--theme-probe'],dir:undefined,error:'explicit absolute path'},
    {args:['--demo','--theme-probe'],dir:'relative',error:'explicit absolute path'},
    {args:['--theme-probe'],dir:join(out,'never-probe'),error:'requires --demo'},
  ];
  for(const c of cases){
    const result=spawnSync(join(repo,'dist/music-ui'),c.args,{env:{...env,MUSIC_UI_THEME_PROBE_DIR:c.dir},encoding:'utf8',timeout:5000});
    expect(result.status).toBe(1);
    expect(result.stderr).toContain(c.error);
    expect(result.signal).toBeNull();
  }
  expect(readdirSync(out).filter(x=>x.startsWith('never-'))).toEqual([]);
});

test('navigation persistence controls separate no-op, serialization-only rewrite and semantic rewrite',()=>{
  const state=parseNavigationState({version:1,history:{entries:[{route:{page:'queue'},selection:0}],cursor:0},order:defaultOrder,libraryView:'covers'});
  const path=join(out,'synthetic-state.json');
  writeFileSync(path,JSON.stringify(state)+'\n',{mode:0o600});
  const store=new NavigationStateStore(path);
  let value=store.read()!;
  const capture=()=>({hash:hash(path),inode:statSync(path).ino,mtime:statSync(path).mtimeMs});
  const initial=capture();
  const detach=store.attach(()=>value);
  try{
    store.flush();
    expect(capture()).toEqual(initial);
    const before=JSON.parse(readFileSync(path,'utf8'));
    value={libraryView:value.libraryView,order:value.order,history:value.history,version:value.version};
    store.flush();
    const serialized=capture();
    expect(serialized.hash).not.toBe(initial.hash);
    expect(serialized.inode).not.toBe(initial.inode);
    expect(JSON.parse(readFileSync(path,'utf8'))).toEqual(before);
    value={...value,history:{...value.history,entries:[{route:{page:'queue'},selection:1}]} };
    store.flush();
    const changed=capture();
    expect(changed.hash).not.toBe(serialized.hash);
    expect(JSON.parse(readFileSync(path,'utf8'))).not.toEqual(before);
    writeFileSync(join(out,'persistence-controls.json'),JSON.stringify({initial,serialized,changed})+'\n');
  }finally{detach();}
});

test('all 22 admitted ramp cases keep real floors; losing-background proof never authorizes the winner',()=>{
  const ramp=JSON.parse(readFileSync(join(repo,'tests/fixtures/palette/host-ramp.json'),'utf8'));
  expect(ramp.cases.length).toBe(22);
  for(const item of ramp.cases){
    const decoded=decodePaletteArtifact(JSON.stringify(item.artifact),()=>{});
    expect(decoded.ok).toBe(true);
    if(!decoded.ok) throw Error(decoded.error);
    const theme=mapPaletteToTheme({retained:decoded.artifact,bundleAssociation:'current-uri'});
    expect(theme.pairs.normal.background).toBe(item.expectedBackground);
    for(const pair of Object.values(theme.pairs)){
      for(const name of ['text','muted','accent','warning','placeholder','caret'] as const) expect(contrast(pair.colors[name],pair.background)).toBeGreaterThanOrEqual(4.5);
      expect(contrast(pair.marker,pair.background)).toBeGreaterThanOrEqual(3);
    }
    expect(contrast(theme.surfaces.progressFill as string,theme.surfaces.progressTrack as string)).toBeGreaterThanOrEqual(3);
  }
  const raw=JSON.parse(readFileSync(join(repo,'tests/fixtures/palette/ok.json'),'utf8'));
  const decode=()=>{const r=decodePaletteArtifact(JSON.stringify(raw),()=>{});if(!r.ok) throw Error(r.error);return r.artifact;};
  const positive=mapPaletteToTheme({retained:decode(),bundleAssociation:'current-uri'});
  expect(positive.pairs.selected.proof.source).toBe('producer');
  raw.features=[];
  raw.verified_pairs=raw.verified_pairs.filter((p:any)=>p.bg!=='selection'&&p.kind!=='delta_l');
  const negative=mapPaletteToTheme({retained:decode(),bundleAssociation:'current-uri'});
  const winner=pairForState(negative,{selected:true,active:true});
  expect(winner.proof.source).toBe('neutral');
  expect(winner).toBe(negative.pairs.selected);
  expect(winner.marker).toBe(winner.colors.text);
  expect(contrast(winner.marker,winner.background)).toBeGreaterThanOrEqual(3);
});
